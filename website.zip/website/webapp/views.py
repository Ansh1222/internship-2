from django.shortcuts import render,redirect
from webapp.models import feedback
from django.contrib import messages


# Create your views here.
def index(request):
    if request.method == "POST":
        name=request.POST['name']
        email=request.POST['email']
        number=request.POST['number']
        message=request.POST['message']
        my_user=feedback(name=name,email=email,number=number,message=message)

        my_user.save()
        print('success')
        messages.success(request,'Your Feedback has been Submited')
        return redirect('/')
    else:
        return render (request,'index.html')
